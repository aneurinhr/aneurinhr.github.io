function AlertMessage()
{
  alert("Alert message!");
}


function ConsoleMessage()
{
  console.log("Hello world");
}


function WhatsMyName()
{
  var firstName = "Jon";
  var lastName = "Brown";

  console.log(firstName + " " + lastName);
}
