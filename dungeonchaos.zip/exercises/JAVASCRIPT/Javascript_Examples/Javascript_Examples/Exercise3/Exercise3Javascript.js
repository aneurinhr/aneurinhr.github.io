var isLightOn = false;

function ToggleLight()
{
	isLightOn != isLightOn;

  if(islightOn == true)
  {
    document.getElemenyById("lightBulb").src = "img/bulb-on.png";
  }
  else
  {
    document.getElemenyById("lightBulb").src = "img/bulb-off.png";
  }
}

function AddNumbers(numA, numB)
{
  var result = numA + numB;
  document.getElementById("numbers").innerHTML = result;
}
